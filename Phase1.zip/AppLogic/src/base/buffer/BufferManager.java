package base.buffer;
import base.models.*;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.SequencedCollection;

import base.models.Record;
import base.storage.StorageManager;

public class BufferManager {

    //max number of pages that can be in buffer before flushing
    private static int maxPageCount;
    private static HashMap<Integer,Page> buffer;
    private DataCatalog dataCatalog;
    private StorageManager storageManager;

    //todo make static instance of the BufferManager similar to how the bufferManager is done
    private static BufferManager bufferManager = null;

    public BufferManager(int maxPageCount, String directory) throws Exception {
        this.maxPageCount = maxPageCount;
        this.storageManager = new StorageManager(directory+"/storage.bin/");
        buffer = new HashMap<>();
    }


    //todo buffer is inside of the buffermanage (stored as Hashmap of Pages)

    //todo to get least recently used page, get the values and find the oldest timestamp

    //todo createNewPage() -> create new Page object and store it in the hashmap

    //todo if createNewPage() is called and the # of entries in the hash, eject the least recently used page to hardware.
    //todo call storage manager to save the page



    public static Page getPage(int pageId){
        if(pageId==-1){
            return null;
        } else if(buffer.containsKey(pageId)){
            Page page = buffer.get(pageId);
            page.timestamp = LocalDateTime.now();
            return page;
        } else {
            try{
                flushOldestPage();
                Page decodedPage = readPageFromHardware(pageId);
                buffer.put(decodedPage.pageId, decodedPage);
                decodedPage.timestamp = LocalDateTime.now();
                return decodedPage;
            } catch (Exception e){
                System.out.println("Inconsistent Database");
                throw new RuntimeException(e);
                //System.exit(0);
            }

        }
        //return null;
    }

    public static Page createNewPage(int id, String table) throws IOException {
        flushOldestPage();
        Page page = new Page(id, table);
        buffer.put(page.pageId, page);
        page.timestamp = LocalDateTime.now();
        return page;
    }

    public static void flushOldestPage() throws IOException {
        if (buffer.size()>= bufferManager.maxPageCount){
            ArrayList<Page> pages = new ArrayList<Page>(buffer.values());
            Page oldestPage = pages.get(0);
            for(Page p : pages){
                if(p.timestamp.isBefore(oldestPage.timestamp)){
                    oldestPage = p;
                }
            }
            writePageToHardware(oldestPage);
            buffer.remove(oldestPage.pageId);
        }

    }

    public static void flushBuffer() throws IOException {
        ArrayList<Page> pages = new ArrayList<Page>(buffer.values());
        for(Page p : pages){
            writePageToHardware(p);
        }
    }

    public static void deletePage(int pageId){
        buffer.remove(pageId);
    }



    public static Page readPageFromHardware(int pageId) throws IOException {

        //get byte array from hardware
        byte[] encodedByteArray = StorageManager.readPage(pageId);
        //System.out.println(Arrays.toString(encodedByteArray));

        int encodedIndex = 0;

        //get nextPageId
        byte[] dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
        encodedIndex+=Integer.BYTES;
        int nextPageId = ByteBuffer.wrap(dataSegment).getInt();


        //get table name
        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
        encodedIndex+=Integer.BYTES;
        int tableLength = ByteBuffer.wrap(dataSegment).getInt();

        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+tableLength));
        encodedIndex+= tableLength;
        String tableName = new String(dataSegment, StandardCharsets.UTF_8);
        //System.out.println("tableName:" +tableName);

        Page finalPage = new Page(pageId, tableName);
        finalPage.nextPageId = nextPageId;
        //SequencedCollection<AttributeSchema> tableSchema = DataCatalog.getInstance().getTableSchema(tableName).getAttributeSchemas().sequencedValues();
        ArrayList<AttributeSchema> tableSchema = new ArrayList<>(DataCatalog.getInstance().getTableSchema(tableName).getAttributeSchemas().sequencedValues());


        while(encodedIndex<encodedByteArray.length){
            Record finalRecord;
            int startByte = encodedIndex;
            //null-byte array
            byte[] nullByteArray = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+tableSchema.size()));
            encodedIndex+=tableSchema.size();
            //System.out.println("null-byte array: "+Arrays.toString(nullByteArray));

            //objects in byte array
            for(int i=0; i<nullByteArray.length; i++){
                AttributeSchema attributeSchema = tableSchema.get(i);
                DataTypes dataType = attributeSchema.getDataType();
                //check that data is != null
                if(nullByteArray[i]!=1){
                    switch(dataType){
                        case DataTypes.INTEGER:
                            encodedIndex+=Integer.BYTES;
                            break;
                        case DataTypes.DOUBLE:
                            encodedIndex+=Double.BYTES;
                            break;
                        case DataTypes.BOOLEAN:
                            encodedIndex+=1;
                            break;
                        case DataTypes.CHAR:
                            byte[] charLengthByte = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
                            encodedIndex+=Integer.BYTES;
                            int charLength = ByteBuffer.wrap(charLengthByte).getInt();
                            encodedIndex+=charLength;
                            break;
                        case DataTypes.VARCHAR:
                            byte[] varLengthByte = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
                            encodedIndex+=Integer.BYTES;
                            int varLength = ByteBuffer.wrap(varLengthByte).getInt();
                            encodedIndex+=varLength;
                            break;
                        default:
                            break;
                    }
                }
            }
            int endByte = encodedIndex;
            finalRecord = convertBytesToRecord(Arrays.copyOfRange(encodedByteArray,startByte,endByte), tableSchema);
            finalPage.recordList.add(finalRecord);
        }

        return finalPage;
    }


    public static Record convertBytesToRecord(byte[] encodedByteArray, ArrayList<AttributeSchema> fakeTableSchema) throws IOException {

        //System.out.println("encoded byteArray: "+Arrays.toString(encodedByteArray));

        int encodedIndex = 0;
        //null-byte array
        byte[] nullByteArray = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+fakeTableSchema.size()));
        encodedIndex+=fakeTableSchema.size();
        //System.out.println("null-byte array: "+Arrays.toString(nullByteArray));

        //objectify byte arrays
        Record record = new Record();
        for(int i=0; i<nullByteArray.length; i++){
            AttributeValue attribute = null;
            AttributeSchema attributeSchema = fakeTableSchema.get(i);
            DataTypes dataType = attributeSchema.getDataType();
            //check if null data
            if(nullByteArray[i]==1){
                attribute = new AttributeValue<>(null, dataType);
            } else {
                byte[] dataSegment;
                switch(dataType){
                    case DataTypes.INTEGER:
                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
                        encodedIndex+=Integer.BYTES;
                        attribute = new AttributeValue<>(ByteBuffer.wrap(dataSegment).getInt(), dataType);
                        break;
                    case DataTypes.DOUBLE:
                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Double.BYTES));
                        encodedIndex+=Double.BYTES;
                        attribute = new AttributeValue<>(ByteBuffer.wrap(dataSegment).getDouble(), dataType);
                        break;
                    case DataTypes.BOOLEAN:
                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+1));
                        encodedIndex+=1;
                        Byte boolByte = ByteBuffer.wrap(dataSegment).get();
                        boolean bool;
                        if(boolByte==1){
                            bool=true;
                        }else{
                            bool=false;
                        }
                        attribute = new AttributeValue<>(bool, dataType);
                        break;
                    case DataTypes.CHAR:
                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
                        encodedIndex+=Integer.BYTES;
                        int charLength = ByteBuffer.wrap(dataSegment).getInt();

                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+charLength));
                        encodedIndex+= charLength;
                        String charArray = new String(dataSegment, StandardCharsets.UTF_8);
                        attribute = new AttributeValue<>(charArray, dataType);
                        break;
                    case DataTypes.VARCHAR:
                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+Integer.BYTES));
                        encodedIndex+=Integer.BYTES;
                        int varLength = ByteBuffer.wrap(dataSegment).getInt();

                        dataSegment = Arrays.copyOfRange(encodedByteArray,encodedIndex,(encodedIndex+varLength));
                        encodedIndex+= varLength;
                        String varArray = new String(dataSegment, StandardCharsets.UTF_8);
                        attribute = new AttributeValue<>(varArray, dataType);
                        break;
                    default:
                        break;
                }

            }

            //AttributeValue attribute = new AttributeValue<>();
            if(attribute!=null){
                record.attributeList.add(attribute);
            }
        }

        return record;

    }



    public static void writePageToHardware(Page page) throws IOException {

        //prevent a page from writing if it has not been modified
        if(page.hasBeenModified==false){
            return;
        }

        //SequencedCollection<AttributeSchema> tableSchema = DataCatalog.getInstance().getTableSchema(page.tableName).getAttributeSchemas().sequencedValues();

        ArrayList<byte[]> byteLists = new ArrayList<>();


        //store nextPageId
        ByteBuffer nextPageId = ByteBuffer.allocate(Integer.BYTES);
        nextPageId.putInt(page.nextPageId);
        byteLists.add(nextPageId.array());

        //store name of table
        String tableName = page.tableName;
        ByteBuffer tableSize = ByteBuffer.allocate(Integer.BYTES);
        tableSize.putInt(tableName.length());
        byteLists.add(tableSize.array());

        byte[] tableNameBytes = tableName.getBytes(StandardCharsets.UTF_8);
        byteLists.add(tableNameBytes);

        //store records
        for(Record record : page.recordList){
            byteLists.add(convertRecordToBytes(record));
        }

        //find size of final array
        int finalByteArraySize = 0;
        for(int i=0; i<byteLists.size(); i++){
            //System.out.println(Arrays.toString(byteLists.get(i)));
            finalByteArraySize+=byteLists.get(i).length;
        }

        byte[] finalByteArray = new byte[finalByteArraySize+Integer.BYTES];

        //put int in array showing how long the page is
        ByteBuffer byteCount = ByteBuffer.allocate(Integer.BYTES);
        byteCount.putInt(finalByteArraySize+Integer.BYTES);
        int finalArrayIndex =0;
        for(byte b : byteCount.array()){
            finalByteArray[finalArrayIndex]=b;
            finalArrayIndex++;
        }

        //populate final array
        for(byte[] list : byteLists){
            for(byte b : list){
                finalByteArray[finalArrayIndex]=b;
                finalArrayIndex++;
            }
        }

        //return finalByteArray;
        ByteBuffer buffer = ByteBuffer.wrap(finalByteArray);


        //System.out.println("buffer lengeth: "+buffer.array().length);
        //System.out.println("final byte array: "+Arrays.toString(buffer.array()));
        StorageManager.writePage(page.pageId, buffer);
    }


    public static byte[] convertRecordToBytes(Record record){

        ArrayList<byte[]> byteLists = new ArrayList<>();

        //make null-bit
        byte[] nullBitArray = new byte[record.attributeList.size()];
        for(int i=0; i<record.attributeList.size(); i++){
            if(record.attributeList.get(i).data==null){
                nullBitArray[i]=1;
            } else {
                nullBitArray[i]=0;
            }
        }
        byteLists.add(nullBitArray);

        //encode values
        for(AttributeValue attributeValue : record.attributeList){

            ByteBuffer byteBuffer = null;

            //System.out.println("Attribute: "+attributeValue);
            if(attributeValue.data!=null){
                switch(attributeValue.type){
                    case DataTypes.INTEGER:
                        byteBuffer = ByteBuffer.allocate(Integer.BYTES);
                        byteBuffer.putInt((Integer) attributeValue.data);
                        break;
                    case DataTypes.DOUBLE:
                        byteBuffer = ByteBuffer.allocate(Double.BYTES);
                        byteBuffer.putDouble((Double) attributeValue.data);
                        break;
                    case DataTypes.BOOLEAN:
                        byteBuffer = ByteBuffer.allocate(1);
                        boolean bool = (Boolean)attributeValue.data;
                        Byte boolByte = (byte)(bool ? 1 : 0);
                        byteBuffer.put(boolByte);
                        break;
                    case DataTypes.CHAR:
                        String str = (String)attributeValue.data;
                        ByteBuffer strSize = ByteBuffer.allocate(Integer.BYTES);
                        strSize.putInt(str.length());
                        byteLists.add(strSize.array());

                        byte[] strBytes = str.getBytes(StandardCharsets.UTF_8);
                        byteLists.add(strBytes);
                        break;
                    case DataTypes.VARCHAR:
                        String var = (String)attributeValue.data;
                        ByteBuffer varSize = ByteBuffer.allocate(Integer.BYTES);
                        varSize.putInt(var.length());
                        byteLists.add(varSize.array());

                        byte[] varBytes = var.getBytes(StandardCharsets.UTF_8);
                        byteLists.add(varBytes);
                        break;

                    default:
                        break;
                }
            }

            if(byteBuffer!=null){
                byte[] byteList = byteBuffer.array();
                byteLists.add(byteList);
            }

        }

        //find size of final array
        int finalByteArraySize = 0;
        for(int i=0; i<byteLists.size(); i++){
            //System.out.println(Arrays.toString(byteLists.get(i)));
            finalByteArraySize+=byteLists.get(i).length;
        }

        byte[] finalByteArray = new byte[finalByteArraySize];

        //populate final array
        int finalArrayIndex = 0;
        for(byte[] list : byteLists){
            for(byte b : list){
                finalByteArray[finalArrayIndex]=b;
                finalArrayIndex++;
            }
        }


        //System.out.println("byte array: "+Arrays.toString(finalByteArray));
        return finalByteArray;

    }

}


class BufferMain{
    public static void main(String[] args) throws Exception {
        DataCatalog.buildCatalog(5000,"data");
        //System.out.println("page size: "+DataCatalog.getInstance().getPageSize());
        BufferManager bufferManager = new BufferManager(5000, "C:/Users/mprok/JavaProjects/Database Impemented Systems/JottQL");

        //make a test table structure


        AttributeValue attribute1 = new AttributeValue(1, DataTypes.INTEGER);
        AttributeValue attribute2 = new AttributeValue(null, DataTypes.DOUBLE);
        AttributeValue attribute3 = new AttributeValue(false, DataTypes.BOOLEAN);
        AttributeValue attribute4 = new AttributeValue("hello", DataTypes.CHAR);
        AttributeValue attribute5 = new AttributeValue("world", DataTypes.VARCHAR);

        Record record1 = new Record();

        record1.attributeList.add(attribute1);
        record1.attributeList.add(attribute2);
        record1.attributeList.add(attribute3);
        record1.attributeList.add(attribute4);
        record1.attributeList.add(attribute5);



        AttributeValue attribute6 = new AttributeValue(4, DataTypes.INTEGER);
        AttributeValue attribute7 = new AttributeValue(5.5, DataTypes.DOUBLE);
        AttributeValue attribute8 = new AttributeValue(true, DataTypes.BOOLEAN);
        AttributeValue attribute9 = new AttributeValue("tuple", DataTypes.CHAR);
        AttributeValue attribute10 = new AttributeValue("varvar char", DataTypes.VARCHAR);
        Record record2 = new Record();


        record2.attributeList.add(attribute6);
        record2.attributeList.add(attribute7);
        record2.attributeList.add(attribute8);
        record2.attributeList.add(attribute9);
        record2.attributeList.add(attribute10);


        bufferManager.createNewPage(1,"table");


        //Page testPage = new Page(1, "table");
        Page testPage = bufferManager.getPage(1);
        testPage.recordList.add(record1);
        testPage.recordList.add(record2);

        //make a test table schema
        TableSchema  tableSchema = new TableSchema();
        tableSchema.tableName = testPage.tableName;
        DataCatalog.getInstance().addTableSchema(tableSchema);


        AttributeSchema integer = AttributeSchema.createAttributeSchemaFromQuery("a INTEGER");
        tableSchema.addAttributeSchema(integer);

        AttributeSchema dub = AttributeSchema.createAttributeSchemaFromQuery("b DOUBLE");
        tableSchema.addAttributeSchema(dub);

        AttributeSchema bool = AttributeSchema.createAttributeSchemaFromQuery("c BOOLEAN");
        tableSchema.addAttributeSchema(bool);

        AttributeSchema car = AttributeSchema.createAttributeSchemaFromQuery("d CHAR(5)");
        tableSchema.addAttributeSchema(car);

        AttributeSchema var = AttributeSchema.createAttributeSchemaFromQuery("e VARCHAR(10)");
        tableSchema.addAttributeSchema(var);

        for(AttributeSchema a : DataCatalog.getInstance().getTableSchema(testPage.tableName).getAttributeSchemas().sequencedValues()){
            //System.out.println("datatype: "+a.getDataType());
        }





        // write it
        byte[] encodedByteArray;
        //ncodedByteArray = bufferManager.writePageToHardware(testPage, fakeTableSchema);
        bufferManager.writePageToHardware(testPage);


        //read it
        System.out.println("Reading...");
        //Page decodedPage = bufferManager.readPageFromHardware(1,encodedByteArray, fakeTableSchema);
        Page decodedPage = bufferManager.readPageFromHardware(1);
        System.out.println("decoded record");
        for(Record record : decodedPage.recordList){
            System.out.println("next record");
            for(AttributeValue attributeValue : record.attributeList){

                System.out.println("\t"+attributeValue);

            }
        }
    }
}
